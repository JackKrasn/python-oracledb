# -*- coding: utf-8 -*-
from .db import *
from .dbexceptions import *
from .orautils import *

__version__ = '1.0.1'  # https://semver.org/lang/ru/
__author__ = 'Evgeniy Krasnukhin'
__author_email__ = 'e.krasnukhin@cft.ru'


