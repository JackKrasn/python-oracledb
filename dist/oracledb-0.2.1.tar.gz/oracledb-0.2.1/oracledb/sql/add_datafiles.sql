alter tablespace SYSTEM add datafile size 400M autoextend on next 128M maxsize unlimited;
alter tablespace SYSTEM add datafile size 400M autoextend on next 128M maxsize unlimited;
alter tablespace SYSTEM add datafile size 400M autoextend on next 128M maxsize unlimited;
alter tablespace SYSAUX add datafile size 400M autoextend on next 128M maxsize unlimited;