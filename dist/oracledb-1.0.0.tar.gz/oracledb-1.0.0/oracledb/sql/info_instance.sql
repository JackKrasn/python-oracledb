begin
  open :cursor for select * from v$instance;
end;
