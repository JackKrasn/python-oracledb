begin
open :cursor for select * from v$database;
end;
