select * from dual;


select * from dual;
