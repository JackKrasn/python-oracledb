Description
===================
The package to manage the Oracle Databases.
This package allows:

  - create new database from template
  - create new database as copy
  - drop database
  - execute statements
  - start/shutdown database
  - start/stop container database
  - get info(instance, db, container)
  - import dump
