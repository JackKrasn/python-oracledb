begin
open :cursor for select * from dba_registry;
end;